from flask import Flask, jsonify
from rf.sdr_scanner import scan_rf

app = Flask(__name__)

@app.route('/status')
def status():
    return jsonify({'status':'online'})

@app.route('/scan')
def scan():
    data = scan_rf()
    return jsonify({'signal': float(sum(data))})

def start_api():
    app.run(host='0.0.0.0', port=5050)
