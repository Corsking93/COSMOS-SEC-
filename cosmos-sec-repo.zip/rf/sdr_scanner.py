from rtlsdr import RtlSdr
import numpy as np

sdr = RtlSdr()
sdr.sample_rate = 2.4e6
sdr.center_freq = 100e6
sdr.gain = 'auto'

def scan_rf():
    samples = sdr.read_samples(256*1024)
    return np.abs(samples)
