from rf.sdr_scanner import scan_rf
from ai.anomaly_engine import detect_anomalies
from api.server import start_api
import time

def boot():
    print('COSMOS-SEC ONLINE')
    start_api()
    while True:
        samples = scan_rf()
        anomalies = detect_anomalies(samples)
        if anomalies:
            print('ANOMALY:', anomalies)
        time.sleep(2)

if __name__ == '__main__':
    boot()
