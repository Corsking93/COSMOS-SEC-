#!/bin/bash
echo Installing COSMOS-SEC
sudo apt update
pip3 install -r requirements.txt
