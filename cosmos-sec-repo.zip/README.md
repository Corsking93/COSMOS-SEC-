# COSMOS-SEC

Edge RF Intelligence + Anomaly Detection Node

## Structure
- core: runtime engine
- rf: SDR scanning
- ai: anomaly + temporal prediction
- api: Flask server
- firmware: hardware control
- mobile_app: Flutter stub
- installer: deployment scripts
