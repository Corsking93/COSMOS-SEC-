import time

history = []

def log(freq, strength):
    history.append({'t':time.time(),'f':freq,'s':strength})

def predict(freq):
    hits = [h for h in history if abs(h['f']-freq)<0.2]
    return None if len(hits)<3 else time.time()+60
