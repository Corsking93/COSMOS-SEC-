from sklearn.ensemble import IsolationForest
import numpy as np

model = IsolationForest(contamination=0.01)

def detect_anomalies(samples):
    data = np.array(samples).reshape(-1,1)
    model.fit(data)
    preds = model.predict(data)
    anomalies = data[preds == -1]
    return {'count': len(anomalies)} if len(anomalies)>0 else None
