# placeholder GPIO control
def rotate(angle):
    print('rotating to', angle)
